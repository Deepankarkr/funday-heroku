import React from 'react';

function Home() {
    return (
      <div>
        <h2>Welcome to EOD Dashboard!!</h2>
      </div>
    );
  }
   
  export default Home;