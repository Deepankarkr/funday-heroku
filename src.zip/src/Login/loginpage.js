import React from 'react';
import './loginpage.css';

class Modal extends React.Component {
  render() {
    return <div className='Modal'>
              <form onSubmit= { this.props.onSubmit }>
                <Input type='text' name='username' placeholder='Username' />
                <Input type='password' name='password' placeholder='Password' />
                <a href='/forget'>Lost your password ?</a>
                <button> Sign In</button>
              </form>
           </div>
  }
}

class Input extends React.Component {
  render() {
    return <div className='Input'>
              <input type={ this.props.type } name={ this.props.name } placeholder={ this.props.placeholder } required autocomplete='false'/>
              <label for={ this.props.name } ></label>
           </div>
  }

}

export default Modal;