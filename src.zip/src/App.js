import React from 'react';
import './App.css';
// import Modal from './Login/loginpage';
import CollapsibleTable from './Tables/tables'
import Home from './Header/head'

function App() {
  return (
    <div className="App">
      <Home />
      <CollapsibleTable />
    </div>
  );
}

export default App;
